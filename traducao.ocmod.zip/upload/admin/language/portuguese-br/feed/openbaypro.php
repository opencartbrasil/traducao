<?php
// Heading
$_['heading_title']	 = 'OpenBay Pro';

// Text
$_['text_module']    = 'Módulos';
$_['text_installed'] = 'O módulo OpenBay Pro já está instalado. Ele está disponível no menu Extensões -> OpenBay Pro';