<?php
// Heading
$_['heading_title']    = 'Menu de lojas';

// Text
$_['text_module']      = 'Módulos';
$_['text_success']     = 'Módulo Menu de lojas modificado com sucesso!';
$_['text_edit']        = 'Configurações do módulo Menu de lojas';

// Entry
$_['entry_admin']      = 'Somente para usuários admin';
$_['entry_status']     = 'Situação';

// Error
$_['error_permission'] = 'Atenção: Você não tem permissão para modificar o módulo Menu de lojas!';