<?php
// Heading
$_['heading_title']    = 'Antispam';

// Text
$_['text_success']     = 'Antispam modificado com sucesso!';
$_['text_list']        = 'Listando Antispam';

// Column
$_['column_name']      = 'Antispam';
$_['column_status']    = 'Situação';
$_['column_action']    = 'Ação';

// Error
$_['error_permission'] = 'Atenção: Você não tem permissão para modificar os antispam!';
