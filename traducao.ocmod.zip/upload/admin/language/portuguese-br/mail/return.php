<?php
// Text
$_['text_subject']       = '%s - Atualização da Devolução nº %s';
$_['text_return_id']     = 'Devolução nº:';
$_['text_date_added']    = 'Data da devolução:';
$_['text_return_status'] = 'Sua solicitação de devolução foi atualizada para a seguinte situação:';
$_['text_comment']       = 'Os comentários para a sua solicitação de devolução são:';
$_['text_footer']        = 'Caso tenha alguma dúvida, responda este e-mail.';