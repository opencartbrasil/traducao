<?php
// Heading
$_['heading_title'] = 'Mapa geográfico de vendas';

$_['text_order']    = 'Pedidos';
$_['text_sale']     = 'Vendas';