<?php
// Heading
$_['heading_title']    = 'Frete fixo';

// Text
$_['text_shipping']    = 'Fretes';
$_['text_success']     = 'Frete fixo modificado com sucesso!';
$_['text_edit']        = 'Configurações do Frete fixo';

// Entry
$_['entry_cost']       = 'Valor fixo';
$_['entry_tax_class']  = 'Grupo de impostos';
$_['entry_geo_zone']   = 'Região geográfica';
$_['entry_status']     = 'Situação';
$_['entry_sort_order'] = 'Posição';

// Error
$_['error_permission'] = 'Atenção: Você não tem permissão para modificar a extensão de frete fixo!';