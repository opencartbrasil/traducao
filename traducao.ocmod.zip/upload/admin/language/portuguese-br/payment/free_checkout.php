<?php
// Heading
$_['heading_title']		 = 'Pagamento grátis';

// Text
$_['text_payment']		 = 'Pagamentos';
$_['text_success']		 = 'Pagamento grátis modificado com sucesso!';
$_['text_edit']          = 'Configurações do Pagamento grátis';

// Entry
$_['entry_order_status'] = 'Situação do pedido';
$_['entry_status']       = 'Situação';
$_['entry_sort_order']   = 'Posição';

// Error
$_['error_permission']   = 'Atenção: Você não tem permissão para modificar a extensão de pagamento Pagamento grátis!';