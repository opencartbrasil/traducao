<?php
// Text
$_['text_title']       = 'Parcelforce 48';
$_['text_description'] = 'Parcelforce 48';
$_['text_weight']      = 'Peso:';
$_['text_insurance']   = 'Segurado até:';
$_['text_time']        = 'Tempo de entrega: Dentro de 48 horas.';