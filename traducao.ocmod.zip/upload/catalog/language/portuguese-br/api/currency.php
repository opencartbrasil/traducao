<?php
// Text
$_['text_success']     = 'A moeda foi modificada com sucesso!';

// Error
$_['error_permission'] = 'Atenção: Você não tem permissão de acesso a API!';
$_['error_currency']   = 'Atenção: O código da moeda não é válido!';