<?php
// Text
$_['text_currency'] = 'Moeda';