<?php

$_['text_title']               = 'Cartão de crédito ou débito';
$_['button_confirm']           = 'Confirmar';

$_['text_postcode_check']      = 'CEP: %s';
$_['text_security_code_check'] = 'Código de segurança: %s';
$_['text_address_check']       = 'Endereço: %s';
$_['text_not_given']           = 'Não comunicado';
$_['text_not_checked']         = 'Não verificado';
$_['text_match']               = 'Matched';
$_['text_not_match']           = 'Not matched';
$_['text_payment_details']     = 'Detalhes do pagamento';

$_['entry_card_type']          = 'Tipo de cartão';